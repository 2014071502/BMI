package com.ramirez.bmi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class weight extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);
    }
    public void back(View view) {
        Intent intentback = new Intent(this, MainActivity.class);
        startActivity(intentback);
    }
    public void submit(View view) {
        Intent intentsubmit = new Intent(this, ComputedBMI.class);
        startActivity(intentsubmit);
    }
}